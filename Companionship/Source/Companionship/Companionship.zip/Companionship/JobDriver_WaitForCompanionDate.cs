﻿using RimWorld;
using System.Collections.Generic;
using Verse;
using Verse.AI;

namespace Riot.Companionship
{
    /// <summary>
    /// Visitor job: go to a Companion Spot and wait there for a Companion.
    /// This job is not yet wired into WorkGivers or AI; it's a foundation
    /// that marks the visitor as "waiting for a companion" while active.
    /// 
    /// Job target A: the Companion Spot (Building_CompanionSpot).
    /// </summary>
    public class JobDriver_WaitForCompanionDate : JobDriver
    {
        private Building_CompanionSpot Spot => TargetA.Thing as Building_CompanionSpot;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            // Reserve the spot so multiple pawns don't all try to stand on the same exact cell.
            // If we want multiple pawns later, we can relax this, but for now keep it simple.
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDestroyedOrNull(TargetIndex.A);

            // 1) Go to the Companion Spot (or its interaction cell).
            yield return Toils_Goto.GotoCell(TargetIndex.A, PathEndMode.Touch);

            // 2) Wait indefinitely, flagged as "waiting for a companion".
            Toil wait = new Toil();
            wait.initAction = delegate
            {
                CompVisitorCompanionship comp = pawn.TryGetComp<CompVisitorCompanionship>();
                if (comp != null)
                {
                    comp.IsWaitingForCompanion = true;
                }
            };

            wait.AddFinishAction(delegate
            {
                CompVisitorCompanionship comp = pawn.TryGetComp<CompVisitorCompanionship>();
                if (comp != null)
                {
                    comp.ResetWaitingState();
                }
            });

            wait.defaultCompleteMode = ToilCompleteMode.Never;
            wait.socialMode = RandomSocialMode.SuperActive;
            wait.handlingFacing = true;

            yield return wait;
        }
    }
}
