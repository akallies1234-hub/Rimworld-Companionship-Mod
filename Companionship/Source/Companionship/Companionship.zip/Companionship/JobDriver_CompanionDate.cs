﻿using RimWorld;
using System.Collections.Generic;
using Verse;
using Verse.AI;

namespace Riot.Companionship
{
    public class JobDriver_CompanionDate : JobDriver
    {
        private Pawn Companion => pawn;
        private Pawn Client => TargetA.Pawn;
        private Building_Bed Bed => TargetB.Thing as Building_Bed;

        private int lovinStartTick = -1;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(Client, job, 1, -1, null, errorOnFailed)
                && pawn.Reserve(Bed, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDestroyedOrNull(TargetIndex.A);
            this.FailOnDestroyedOrNull(TargetIndex.B);

            // 1) Move companion to client.
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);

            // 2) Move to the bed's interaction cell.
            yield return Toils_Goto.GotoThing(TargetIndex.B, PathEndMode.InteractionCell);

            // 3) Lovin phase: social interaction over some time.
            Toil lovin = new Toil();
            lovin.initAction = delegate
            {
                lovinStartTick = Find.TickManager.TicksGame;
            };
            lovin.defaultCompleteMode = ToilCompleteMode.Delay;
            lovin.defaultDuration = 2500; // ~1 in-game hour
            lovin.socialMode = RandomSocialMode.SuperActive;
            yield return lovin;

            // 4) Finish the date: evaluate, reward, etc.
            Toil finish = new Toil();
            finish.initAction = delegate
            {
                FinishDate();
            };
            finish.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return finish;
        }

        private void FinishDate()
        {
            if (Companion == null || Client == null || Bed == null)
            {
                return;
            }

            bool success = true;

            // If the "lovin" phase was extremely short, treat it as a failure.
            if (lovinStartTick > 0)
            {
                int duration = Find.TickManager.TicksGame - lovinStartTick;
                if (duration < 200)
                {
                    success = false;
                }
            }

            // XP and date stats for the companion.
            CompCompanionship comp = Companion.TryGetComp<CompCompanionship>();
            if (comp != null)
            {
                if (success)
                {
                    comp.AddXP(2);
                }
                else
                {
                    comp.AddXP(1);
                }

                comp.RecordDate(success);
            }

            // If the date failed (interrupted), no moodlet and no payment.
            if (!success)
            {
                // Even on failure, the client is effectively "done" with this attempt.
                // We do NOT roll for additional service here; that will be reserved for real completions.
                Client.jobs?.EndCurrentJob(JobCondition.Incompletable);
                return;
            }

            // Successful date: calculate outcome, apply moodlets, and pay.
            DateOutcome outcome = DateOutcomeUtility.CalculateOutcome(Companion, Client, Bed);
            DateOutcomeUtility.ApplyDateOutcome(Companion, Client, outcome);
            PaymentUtility.PayForDate(Companion, Client, outcome, Bed);

            // Notify the visitor's companionship comp that they received service.
            CompVisitorCompanionship visitorComp = Client.TryGetComp<CompVisitorCompanionship>();
            if (visitorComp != null)
            {
                visitorComp.Notify_ServiceReceived();
                visitorComp.ResetWaitingState();
            }

            // Explicitly end the client's waiting job so they don't get stuck.
            Client.jobs?.EndCurrentJob(JobCondition.Succeeded);
        }
    }
}
